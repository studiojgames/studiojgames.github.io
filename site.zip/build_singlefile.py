#!/usr/bin/env python3
# 分割ソース -> 単一HTML(base64埋め込み) ビルドスクリプト
# 使い方: python3 build_singlefile.py  → red_alliance_1file.html を生成
import re, base64, os, mimetypes

ROOT=os.path.dirname(os.path.abspath(__file__))

def to_data_uri(path):
    ext=os.path.splitext(path)[1].lower()
    mime={'.webp':'image/webp','.png':'image/png','.jpg':'image/jpeg',
          '.jpeg':'image/jpeg','.mp3':'audio/mpeg','.gif':'image/gif'}.get(ext,'application/octet-stream')
    with open(path,'rb') as f:
        b=base64.b64encode(f.read()).decode()
    return f'data:{mime};base64,{b}'

def inline_asset_paths(text):
    # assets/.../file.ext を data URI に置換（引用符内・url()内・JSパス文字列すべて）
    pat=re.compile(r'(?:\.\./)?assets/[A-Za-z0-9_./-]+\.(?:webp|png|jpe?g|mp3|gif)(?:\?v=\d+)?')
    def repl(m):
        rel=m.group(0)
        rel=rel.split('?')[0]
        rel=rel[3:] if rel.startswith('../') else rel  # CSS内の ../assets 対応
        p=os.path.join(ROOT,rel)
        if os.path.exists(p):
            return to_data_uri(p)
        return m.group(0)
    return pat.sub(repl,text)

html=open(os.path.join(ROOT,'index.html'),encoding='utf-8').read()
css=open(os.path.join(ROOT,'css/style.css'),encoding='utf-8').read()
js=open(os.path.join(ROOT,'js/game.js'),encoding='utf-8').read()
questjs=''
_qp=os.path.join(ROOT,'js/quest.js')
if os.path.exists(_qp):
    questjs=open(_qp,encoding='utf-8').read()

css=inline_asset_paths(css)
js=inline_asset_paths(js)
html=inline_asset_paths(html)

# <link rel=stylesheet ...> を <style> に置換
html=re.sub(r'<link rel="stylesheet" href="css/style\.css(?:\?v=\d+)?">',
            '<style>\n'+css+'\n</style>',html)
# <script src="js/game.js"> を インライン化
html=re.sub(r'<script src="js/game\.js(?:\?v=\d+)?"></script>',
            '<script>\n'+js+'\n</script>',html)
# <script src="js/quest.js"> を インライン化
html=re.sub(r'<script src="js/quest\.js(?:\?v=\d+)?"></script>',
            ('<script>\n'+questjs+'\n</script>') if questjs else '',html)

out=os.path.join(ROOT,'red_alliance_1file.html')
open(out,'w',encoding='utf-8').write(html)
print('built:',out, round(len(html)/1024/1024,2),'MB')
