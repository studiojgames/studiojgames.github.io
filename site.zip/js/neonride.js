/* ============================================================
   NEON RIDE  —  ネオン夜道を奥へ疾走するおまけミニゲーム
   ・一定速度でまったり進む / 左右の壁(ネオン縁)に当たるとGAME OVER
   ・操作: 左右ボタン + スマホ傾け(両対応)
   ・スコア = 走った距離(m)。ハイスコアはSaveManager(無ければlocalStorage)に保存
   ・乗り物 = バイク(真後ろ視点)。assets/ride/bike.webp があれば差し替え表示
   ・BGM = <audio id="rideBgm">（J が Suno で用意した曲を後で src 差し込み）
   公開API: window.NeonRide = { start, isRunning, quit }
   ============================================================ */
(function(){
  'use strict';

  let cv=null, cx=null;
  let raf=null, running=false, paused=false;
  let VW=0, VH=0, DPR=1;

  // ---- 走行状態 ----
  let speed=0;            // 奥行き方向のスピード(疑似)
  const SPEED_BASE=520;   // 一定速度(まったり)。px/s相当の内部単位
  let dist=0;             // 走った距離(m換算)
  let playerX=0;          // 自機の左右位置 -1(左端)..+1(右端)
  let playerVX=0;         // 自機の左右速度
  let roadCurve=0;        // 現在のカーブ量(緩やかに揺れる)
  let curveTarget=0, curveTimer=0;
  let segScroll=0;        // 路面ストライプのスクロール位相
  let started=0;          // 開始時刻
  let gameOver=false, overT=0;
  let best=0;

  // ---- 入力 ----
  let inLeft=false, inRight=false;   // ボタン
  let tilt=0;                        // 傾き -1..+1
  let tiltEnabled=false;

  // ---- バイク画像(あれば) ----
  let bikeImg=null, bikeReady=false;
  // ---- 遠景の街画像 ----
  let cityImg=null, cityReady=false;
  // ---- 操作モード: 'button'=左右ボタン / 'tilt'=スマホ傾け ----
  let ctrlMode='button';
  // ---- 音解析(音ゲー化): BGMの低音(ビート)を拾ってスピード&難易度に反映 ----
  let audioCtx=null, analyser=null, srcNode=null, freqData=null;
  let beatEnergy=0;        // 現在の低音エネルギー(0..1 平滑化)
  let beatPulse=0;         // ビート瞬間のパルス(0..1 減衰)
  let bassAvg=0.15;        // 低音の移動平均(相対比較用)
  let beatHold=0;          // 連続ビート抑制

  // ---- 星(遠景) ----
  let stars=[];

  function $(id){ return document.getElementById(id); }

  function loadBest(){
    try{
      if(window.Save && Save.get){ const v=Save.get('neonride_best'); if(v!=null) return +v||0; }
    }catch(e){}
    try{ return +(localStorage.getItem('ra_neonride_best')||0)||0; }catch(e){ return 0; }
  }
  function saveBest(v){
    try{ if(window.Save && Save.set){ Save.set('neonride_best', v); } }catch(e){}
    try{ localStorage.setItem('ra_neonride_best', String(v)); }catch(e){}
  }
  function loadCtrlMode(){
    try{ const m=localStorage.getItem('ra_neonride_ctrl'); if(m==='tilt'||m==='button') return m; }catch(e){}
    return 'button';
  }
  function saveCtrlMode(m){ try{ localStorage.setItem('ra_neonride_ctrl', m); }catch(e){} }

  function fitCanvas(){
    if(!cv) return;
    DPR=Math.min(2, window.devicePixelRatio||1);
    VW=cv.clientWidth; VH=cv.clientHeight;
    cv.width=Math.round(VW*DPR); cv.height=Math.round(VH*DPR);
    cx.setTransform(DPR,0,0,DPR,0,0);
  }

  function initStars(){
    stars=[];
    for(let i=0;i<70;i++){
      stars.push({ x:Math.random(), y:Math.random()*0.5, s:Math.random()*1.6+0.4, tw:Math.random()*6.28 });
    }
  }

  // ---- 傾き操作 ----
  function onTilt(e){
    if(!running) return;
    // gamma: 左右の傾き(端末を横持ち) -90..90 → landscape前提でbetaやgammaを使い分け
    let g=e.gamma; // 横持ちだと前後、beta が左右になる場合も。landscape固定なので beta を主に使う
    let b=e.beta;
    // landscape(横向きロック)では beta が左右の傾きに相当することが多い
    let v = (b!=null ? b : g) || 0;
    // -30..30度を -1..1 にマップ、デッドゾーン3度
    let n = v/30;
    if(Math.abs(v)<3) n=0;
    tilt = Math.max(-1, Math.min(1, n));
    tiltEnabled = true;
  }
  function enableTilt(){
    try{
      if(typeof DeviceOrientationEvent!=='undefined' &&
         typeof DeviceOrientationEvent.requestPermission==='function'){
        DeviceOrientationEvent.requestPermission().then(p=>{
          if(p==='granted') window.addEventListener('deviceorientation', onTilt, true);
        }).catch(()=>{});
      } else {
        window.addEventListener('deviceorientation', onTilt, true);
      }
    }catch(e){}
  }
  function disableTilt(){
    try{ window.removeEventListener('deviceorientation', onTilt, true); }catch(e){}
    tilt=0; tiltEnabled=false;
  }

  // ---- BGM ----
  function startBGM(){
    const a=$('rideBgm'); if(!a) return;
    try{
      // SFXがミュートなら鳴らさない(本体の設定に従う)
      if(window.RA && RA.SFX && RA.SFX.on===false) return;
      a.volume=0.75 * ((window.RA&&RA.SFX&&typeof RA.SFX.bgmVol==='number')?RA.SFX.bgmVol:1);
      a.currentTime=0;
      const p=a.play(); if(p&&p.catch) p.catch(()=>{});
      setupAnalyser(a);
    }catch(e){}
  }
  // BGMの周波数解析を準備(音ゲー化の心臓部)
  function setupAnalyser(a){
    try{
      if(!audioCtx){
        const AC=window.AudioContext||window.webkitAudioContext;
        if(!AC) return;
        audioCtx=new AC();
      }
      if(audioCtx.state==='suspended') audioCtx.resume();
      if(!srcNode){
        srcNode=audioCtx.createMediaElementSource(a);
        analyser=audioCtx.createAnalyser();
        analyser.fftSize=256; analyser.smoothingTimeConstant=0.6;
        freqData=new Uint8Array(analyser.frequencyBinCount);
        srcNode.connect(analyser);
        analyser.connect(audioCtx.destination);
      }
    }catch(e){ analyser=null; }
  }
  // 毎フレーム低音を読んでビート検出
  function readBeat(dt){
    if(!analyser || !freqData){ beatEnergy=0; beatPulse=Math.max(0,beatPulse-dt*4); return; }
    analyser.getByteFrequencyData(freqData);
    // 低音域(最初の数ビン=キック/ベース)の平均
    let sum=0, n=6;
    for(let i=0;i<n;i++) sum+=freqData[i];
    const bass=(sum/n)/255;            // 0..1
    beatEnergy += (bass-beatEnergy)*Math.min(1, dt*8);
    bassAvg += (bass-bassAvg)*Math.min(1, dt*0.6);  // ゆっくり追従する基準
    // 基準を一定以上上回ったらビート
    beatHold-=dt;
    if(bass > bassAvg*1.35 && bass>0.18 && beatHold<=0){
      beatPulse=1; beatHold=0.18;     // 連打抑制
    } else {
      beatPulse=Math.max(0, beatPulse-dt*3.2);
    }
  }
  function stopBGM(){ const a=$('rideBgm'); if(a){ try{ a.pause(); a.currentTime=0; }catch(e){} } }
  // 本体BGMを全部止める(タイトル/ロビー/バトル/合成/クエスト)
  function silenceOthers(){
    try{ const s=window.RA&&RA.SFX; if(!s) return;
      s.stopTitleBGM&&s.stopTitleBGM(); s.stopLobbyBGM&&s.stopLobbyBGM();
      s.stopBattleBGM&&s.stopBattleBGM(); s.stopBGM&&s.stopBGM();
      s.stopQuestBGM&&s.stopQuestBGM();
    }catch(e){}
  }

  // ---- ライフサイクル ----
  function start(){
    cv=$('rideCanvas'); if(!cv) return;
    cx=cv.getContext('2d');
    $('rideScreen').classList.remove('hidden');
    document.body.classList.add('in-ride');
    fitCanvas(); initStars();
    // 状態リセット
    speed=0; dist=0; playerX=0; playerVX=0; roadCurve=0; curveTarget=0; curveTimer=0;
    segScroll=0; gameOver=false; overT=0; tilt=0; inLeft=inRight=false;
    best=loadBest();
    ctrlMode=loadCtrlMode();
    $('rideResult').classList.add('hidden');
    $('ridePauseMenu').classList.add('hidden');
    syncCtrlUI();
    bindControls();
    if(ctrlMode==='tilt') enableTilt();
    silenceOthers();
    startBGM();
    running=true; paused=false; started=performance.now();
    lastT=0;
    if(raf) cancelAnimationFrame(raf);
    raf=requestAnimationFrame(loop);
  }

  function quit(){
    running=false; paused=false;
    if(raf){ cancelAnimationFrame(raf); raf=null; }
    stopBGM(); disableTilt();
    $('rideScreen').classList.add('hidden');
    document.body.classList.remove('in-ride');
    if(typeof window.showTitle==='function') window.showTitle();
  }

  function endGame(){
    if(gameOver) return;
    gameOver=true; overT=performance.now();
    stopBGM();
    const score=Math.floor(dist);
    if(score>best){ best=score; saveBest(best); }
    if(window.RA && RA.SFX && RA.SFX.thunder) { try{ RA.SFX.thunder(); }catch(e){} }
  }

  function showResult(){
    const score=Math.floor(dist);
    const body=$('rideResultBody');
    const isNew = (score>=best && score>0);
    if(body){
      body.innerHTML =
        '<div class="rr-title">CRASH!</div>'+
        '<div class="rr-score">'+score+' m</div>'+
        '<div class="rr-best">BEST '+best+' m'+(isNew?' <span class="rr-new">NEW!</span>':'')+'</div>';
    }
    $('rideResult').classList.remove('hidden');
  }

  // ---- メインループ ----
  let lastT=0;
  function loop(t){
    if(!running){ return; }
    if(!lastT) lastT=t;
    let dt=(t-lastT)/1000; lastT=t;
    if(dt>0.05) dt=0.05; // タブ復帰などの巨大dtを抑制
    if(!paused){
      update(dt);
      draw();
    }
    raf=requestAnimationFrame(loop);
  }

  function update(dt){
    readBeat(dt);   // BGMの低音を解析(音ゲーの心臓)

    if(gameOver){
      // クラッシュ後、少し見せてから結果
      if(performance.now()-overT>900 && $('rideResult').classList.contains('hidden')){
        showResult();
      }
      // 減速しながら止まる
      speed=Math.max(0, speed-1400*dt);
      segScroll += speed*dt*0.02;
      return;
    }

    // ===== 難易度: 距離が伸びるほど速く・カーブもキツく =====
    const diff = Math.min(1, dist/1200);        // 0..1 (約1200mで最高難度)
    const baseSpeed = SPEED_BASE*(1 + diff*0.9); // 最大1.9倍まで上がる

    // ===== 音ゲー: ビートに合わせてスピードを脈動 =====
    // beatEnergy(低音の量)で基準を底上げ、beatPulse(瞬間)でドンッと加速
    const musical = baseSpeed * (1 + beatEnergy*0.18 + beatPulse*0.35);
    speed += (musical-speed)*Math.min(1, dt*4.0);

    dist += speed*dt*0.06;            // m換算
    segScroll += speed*dt*0.02;        // 路面スクロール

    // カーブを揺らす。難易度が上がるほど頻繁＆急に。ビートで切り替わりやすく
    curveTimer-=dt*(1+diff*0.8);
    if(curveTimer<=0 || (beatPulse>0.8 && Math.random()<0.25)){
      const amp=0.5+diff*0.7;                       // 難度でカーブ振幅UP
      curveTarget=(Math.random()*2-1)*amp;
      curveTimer=(2.2-diff*1.2)+Math.random()*(2.4-diff*1.2);
    }
    roadCurve += (curveTarget-roadCurve)*Math.min(1, dt*(0.7+diff*0.6));

    // 入力 → 横移動。操作モードに応じてボタン or 傾けのどちらか
    let ax=0;
    if(ctrlMode==='button'){
      if(inLeft) ax-=1; if(inRight) ax+=1;
    } else { // tilt
      if(tiltEnabled) ax = tilt*1.25;
    }
    ax = Math.max(-1.4, Math.min(1.4, ax));
    // カーブで外側に流される(疾走感)。速いほど流れも強い
    const drift = roadCurve*(0.45+diff*0.35);
    playerVX += (ax*2.6 - drift)*dt*3.0;
    playerVX *= Math.pow(0.0008, dt); // 減衰
    playerX += playerVX*dt;

    // 壁判定: |playerX|>=1 でクラッシュ
    if(playerX<=-1){ playerX=-1; endGame(); }
    if(playerX>= 1){ playerX= 1; endGame(); }
  }

  // ---- 描画(疑似3D) ----
  function draw(){
    const W=VW, H=VH;
    const horizon=H*0.42;           // 地平線
    // 背景: 上=夜空グラデ
    let sky=cx.createLinearGradient(0,0,0,horizon);
    sky.addColorStop(0,'#0a0612'); sky.addColorStop(1,'#1a0e2e');
    cx.fillStyle=sky; cx.fillRect(0,0,W,horizon);
    // 星
    const tt=performance.now()/1000;
    cx.save();
    for(const s of stars){
      const a=0.4+0.4*Math.sin(tt*2+s.tw);
      cx.globalAlpha=a; cx.fillStyle='#cfe8ff';
      cx.fillRect(s.x*W, s.y*horizon, s.s, s.s);
    }
    cx.restore(); cx.globalAlpha=1;

    // 遠景の街: アップ画像があれば使う。無ければ簡易シルエット
    if(cityReady && cityImg){
      const off = -roadCurve*W*0.05;   // カーブで僅かパララックス
      // 画像の下端を地平線に合わせ、画面幅より少し広げて左右に動かせるように
      const iw=W*1.12, ih=iw*cityImg.height/cityImg.width;
      const dx=(W-iw)/2 + off;
      const dy=horizon-ih;
      cx.drawImage(cityImg, dx, dy, iw, ih);
      // 地平線付近をネオン霧でなじませる
      let fog=cx.createLinearGradient(0,horizon-H*0.12,0,horizon+2);
      fog.addColorStop(0,'rgba(26,14,46,0)'); fog.addColorStop(1,'rgba(20,12,38,0.85)');
      cx.fillStyle=fog; cx.fillRect(0,horizon-H*0.12,W,H*0.12+2);
    } else {
      drawSkyline(W, horizon);
    }

    // 路面: 地平線から下を暗い路面で塗る
    let grd=cx.createLinearGradient(0,horizon,0,H);
    grd.addColorStop(0,'#0b0a18'); grd.addColorStop(1,'#141226');
    cx.fillStyle=grd; cx.fillRect(0,horizon,W,H-horizon);

    // 消失点(カーブで左右にずれる)
    const vpX = W/2 + roadCurve*W*0.16;

    // 道路を奥→手前へ台形で。中央の道幅を手前ほど広げる
    const roadHalfTop=W*0.012;     // 地平線での半幅
    const roadHalfBot=W*0.46;      // 手前での半幅

    // 路面のネオン縁(左=ピンク, 右=シアン)＋点線センター＋横ストライプ
    const N=60; // 奥行き分割
    // まず路面パネルを縞で(スクロールで流れる)
    for(let i=0;i<N;i++){
      const f0=i/N, f1=(i+1)/N;     // 0=奥 1=手前
      const y0=lerp(horizon, H, ease(f0));
      const y1=lerp(horizon, H, ease(f1));
      const hw0=lerp(roadHalfTop, roadHalfBot, ease(f0));
      const hw1=lerp(roadHalfTop, roadHalfBot, ease(f1));
      const cx0=lerp(vpX, W/2, ease(f0));
      const cx1=lerp(vpX, W/2, ease(f1));
      // 縞(スクロール位相で明暗交互)
      const phase=Math.floor((f0*20 + segScroll))%2;
      cx.fillStyle = phase===0 ? 'rgba(30,26,52,0.9)' : 'rgba(20,17,38,0.9)';
      cx.beginPath();
      cx.moveTo(cx0-hw0,y0); cx.lineTo(cx0+hw0,y0);
      cx.lineTo(cx1+hw1,y1); cx.lineTo(cx1-hw1,y1); cx.closePath(); cx.fill();
    }

    // ネオン縁(左ピンク/右シアン) — 太いラインを奥→手前で
    drawEdge(vpX, horizon, H, roadHalfTop, roadHalfBot, -1, '#ff2db8');
    drawEdge(vpX, horizon, H, roadHalfTop, roadHalfBot, +1, '#37e6ff');

    // センター点線
    drawCenter(vpX, horizon, H, roadHalfTop, roadHalfBot);

    // 自機(バイク)
    drawBike(W,H);

    // HUD
    drawHUD(W,H);

    // クラッシュ演出
    if(gameOver){
      cx.fillStyle='rgba(255,40,60,'+Math.min(0.4, (performance.now()-overT)/1200*0.4)+')';
      cx.fillRect(0,0,W,H);
    }
  }

  function drawSkyline(W, horizon){
    // 遠くのビル群を矩形で。距離方向はほぼ固定、カーブで僅かにパララックス
    const off = -roadCurve*W*0.04;
    cx.save();
    cx.fillStyle='#0d0b1c';
    let x=-40+off;
    let seed=1234;
    function rnd(){ seed=(seed*9301+49297)%233280; return seed/233280; }
    while(x<W+40){
      const bw=18+rnd()*46;
      const bh=20+rnd()*horizon*0.55;
      cx.fillRect(x, horizon-bh, bw, bh);
      // 窓灯り
      cx.fillStyle = rnd()>0.5 ? 'rgba(90,200,255,0.25)' : 'rgba(255,120,200,0.22)';
      for(let wy=horizon-bh+6; wy<horizon-4; wy+=8){
        for(let wx=x+3; wx<x+bw-3; wx+=7){
          if(rnd()>0.6) cx.fillRect(wx,wy,2,3);
        }
      }
      cx.fillStyle='#0d0b1c';
      x+=bw+6+rnd()*10;
    }
    cx.restore();
  }

  function drawEdge(vpX, horizon, H, hwTop, hwBot, side, color){
    cx.save();
    cx.strokeStyle=color; cx.lineWidth=Math.max(3, VW*0.006);
    cx.shadowColor=color; cx.shadowBlur=18; cx.globalAlpha=0.95;
    cx.beginPath();
    const N=40;
    for(let i=0;i<=N;i++){
      const f=i/N;
      const y=lerp(horizon,H,ease(f));
      const hw=lerp(hwTop,hwBot,ease(f));
      const cxx=lerp(vpX,VW/2,ease(f));
      const x=cxx+side*hw;
      if(i===0) cx.moveTo(x,y); else cx.lineTo(x,y);
    }
    cx.stroke();
    cx.restore();
  }

  function drawCenter(vpX, horizon, H, hwTop, hwBot){
    cx.save();
    cx.strokeStyle='rgba(220,235,255,0.7)';
    cx.lineWidth=Math.max(2, VW*0.004);
    const N=40;
    for(let i=0;i<N;i++){
      // 点線(スクロールで流れる)
      if((i+Math.floor(segScroll))%2!==0) continue;
      const f0=i/N, f1=(i+0.6)/N;
      const y0=lerp(horizon,H,ease(f0)), y1=lerp(horizon,H,ease(f1));
      const cx0=lerp(vpX,VW/2,ease(f0)), cx1=lerp(vpX,VW/2,ease(f1));
      cx.beginPath(); cx.moveTo(cx0,y0); cx.lineTo(cx1,y1); cx.stroke();
    }
    cx.restore();
  }

  function drawBike(W,H){
    // 自機の画面位置: playerX(-1..1) を路面の手前半幅にマップ
    const baseY=H*0.82;
    const px = W/2 + playerX*(W*0.40);
    const bw = W*0.16;
    // 画像があれば実アスペクト比で高さを決める(縦長バイク画像が潰れないように)
    const bh = (bikeReady && bikeImg) ? bw*(bikeImg.naturalHeight/bikeImg.naturalWidth) : bw*1.1;
    if(bikeReady && bikeImg){
      cx.save();
      // 左右移動で軽く傾ける
      cx.translate(px, baseY);
      cx.rotate(playerVX*0.12);
      cx.drawImage(bikeImg, -bw/2, -bh, bw, bh);
      cx.restore();
    } else {
      // 仮スプライト(ネオンのバイク風シルエット)
      cx.save();
      cx.translate(px, baseY); cx.rotate(playerVX*0.12);
      // 後輪
      cx.fillStyle='#15131f'; cx.strokeStyle='#37e6ff'; cx.lineWidth=3;
      cx.shadowColor='#37e6ff'; cx.shadowBlur=14;
      roundRect(-bw*0.22, -bh*0.42, bw*0.44, bh*0.5, 8); cx.fill(); cx.stroke();
      // ボディ
      cx.fillStyle='#1c1830'; cx.strokeStyle='#ff2db8'; cx.shadowColor='#ff2db8';
      roundRect(-bw*0.30, -bh*0.78, bw*0.60, bh*0.42, 10); cx.fill(); cx.stroke();
      // ライダー頭
      cx.beginPath(); cx.fillStyle='#241c3a'; cx.arc(0,-bh*0.92, bw*0.13, 0, 6.28); cx.fill(); cx.stroke();
      // テールランプ
      cx.shadowBlur=20; cx.shadowColor='#ff3b3b'; cx.fillStyle='#ff5a5a';
      cx.beginPath(); cx.arc(0,-bh*0.30, bw*0.06, 0, 6.28); cx.fill();
      cx.restore();
    }
    cx.shadowBlur=0;
  }

  function drawHUD(W,H){
    cx.save();
    cx.fillStyle='#dff6ff'; cx.font='bold '+Math.round(H*0.05)+'px system-ui,sans-serif';
    cx.textBaseline='top'; cx.shadowColor='#37e6ff'; cx.shadowBlur=8;
    cx.fillText(Math.floor(dist)+' m', 16, 12);
    cx.font='bold '+Math.round(H*0.032)+'px system-ui,sans-serif';
    cx.fillStyle='#ffd0ee'; cx.shadowColor='#ff2db8';
    cx.fillText('BEST '+best+' m', 16, 12+Math.round(H*0.058));
    cx.restore(); cx.shadowBlur=0;
  }

  // ---- utils ----
  function lerp(a,b,t){ return a+(b-a)*t; }
  function ease(f){ return f*f; } // 手前ほど密に(奥が詰まる遠近感)
  function roundRect(x,y,w,h,r){
    cx.beginPath();
    cx.moveTo(x+r,y); cx.arcTo(x+w,y,x+w,y+h,r); cx.arcTo(x+w,y+h,x,y+h,r);
    cx.arcTo(x,y+h,x,y,r); cx.arcTo(x,y,x+w,y,r); cx.closePath();
  }

  // ---- 入力バインド ----
  let bound=false;
  function bindControls(){
    if(bound) return; bound=true;
    const L=$('rideLeft'), R=$('rideRight');
    const press=(el,set)=>{
      if(!el) return;
      const on=e=>{ e.preventDefault(); set(true); };
      const off=e=>{ e.preventDefault(); set(false); };
      el.addEventListener('touchstart',on,{passive:false});
      el.addEventListener('touchend',off,{passive:false});
      el.addEventListener('touchcancel',off,{passive:false});
      el.addEventListener('mousedown',on); el.addEventListener('mouseup',off);
      el.addEventListener('mouseleave',off);
    };
    press(L, v=>inLeft=v); press(R, v=>inRight=v);
    // キーボード(PC確認用)
    window.addEventListener('keydown', e=>{
      if(!running) return;
      if(e.key==='ArrowLeft'||e.key==='a') inLeft=true;
      if(e.key==='ArrowRight'||e.key==='d') inRight=true;
    });
    window.addEventListener('keyup', e=>{
      if(e.key==='ArrowLeft'||e.key==='a') inLeft=false;
      if(e.key==='ArrowRight'||e.key==='d') inRight=false;
    });
    // 結果画面ボタン
    const rt=$('rideRetry'), rc=$('rideClose');
    if(rt) rt.addEventListener('click', ()=>{ $('rideResult').classList.add('hidden'); restart(); });
    if(rc) rc.addEventListener('click', quit);
    // ポーズ
    const pb=$('ridePause'); if(pb) pb.addEventListener('click', pauseGame);
    const rsm=$('ridePmResume'); if(rsm) rsm.addEventListener('click', resumeGame);
    const qb=$('ridePmQuit'); if(qb) qb.addEventListener('click', quit);
    // 操作モード切替(ポーズ内)
    const bB=$('rideModeBtn'), bT=$('rideModeTilt');
    if(bB) bB.addEventListener('click', ()=>setCtrlMode('button'));
    if(bT) bT.addEventListener('click', ()=>setCtrlMode('tilt'));
    // リサイズ
    window.addEventListener('resize', ()=>{ if(running) fitCanvas(); });
  }

  function restart(){
    speed=0; dist=0; playerX=0; playerVX=0; roadCurve=0; curveTarget=0; curveTimer=0;
    segScroll=0; gameOver=false; overT=0; tilt=0; inLeft=inRight=false;
    started=performance.now(); lastT=0;
    startBGM();
  }

  // ---- ポーズ＆操作切替 ----
  function pauseGame(){
    if(!running || gameOver || paused) return;
    paused=true;
    syncCtrlUI();
    $('ridePauseMenu').classList.remove('hidden');
    const a=$('rideBgm'); if(a){ try{ a.pause(); }catch(e){} }
  }
  function resumeGame(){
    if(!paused) return;
    paused=false;
    $('ridePauseMenu').classList.add('hidden');
    const a=$('rideBgm'); if(a && !gameOver){ try{ const p=a.play(); if(p&&p.catch)p.catch(()=>{}); }catch(e){} }
    lastT=0;
  }
  function setCtrlMode(m){
    ctrlMode=m; saveCtrlMode(m);
    inLeft=inRight=false; tilt=0;
    if(m==='tilt') enableTilt(); else disableTilt();
    syncCtrlUI();
  }
  // 操作モードに応じてUIの見た目を同期(ボタン表示/ハイライト)
  function syncCtrlUI(){
    const ctr=$('rideControls');
    if(ctr) ctr.style.display = (ctrlMode==='button') ? 'flex' : 'none';
    const bB=$('rideModeBtn'), bT=$('rideModeTilt');
    if(bB) bB.classList.toggle('on', ctrlMode==='button');
    if(bT) bT.classList.toggle('on', ctrlMode==='tilt');
  }

  // ---- バイク画像の遅延読み込み(あれば差し替え) ----
  (function tryLoadBike(){
    const img=new Image();
    img.onload=()=>{ bikeImg=img; bikeReady=true; };
    img.onerror=()=>{ bikeReady=false; }; // 無ければ仮スプライトのまま
    img.src='assets/ride/bike.webp?v=1';
  })();
  // ---- 遠景の街画像を読み込み ----
  (function tryLoadCity(){
    const img=new Image();
    img.onload=()=>{ cityImg=img; cityReady=true; };
    img.onerror=()=>{ cityReady=false; };
    img.src='assets/ride/city_bg.webp?v=2';
  })();

  // ---- 公開 ----
  window.NeonRide = {
    start: start,
    isRunning: function(){ return !!running; },
    quit: quit
  };
})();
